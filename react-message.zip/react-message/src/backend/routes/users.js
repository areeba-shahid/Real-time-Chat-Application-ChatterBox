const express = require("express");
const router = express.Router();
const auth = require("../firebaseAdmin");

// Route to check if an email exists among all users
router.get("/check-email/:email", async (req, res) => {
  const { email } = req.params;
  try {
    const users = await auth.listUsers();
    const userExists = users.users.some((user) => user.email === email);
    res.json({ exists: userExists });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
