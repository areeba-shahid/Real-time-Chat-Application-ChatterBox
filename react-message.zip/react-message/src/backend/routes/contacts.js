// backend/routes/contacts.js
const express = require("express");
const router = express.Router();
const auth = require("../firebaseAdmin");

// Route to add a contact by checking if the user exists
router.post("/add-contact", async (req, res) => {
  const { email } = req.body;
  try {
    // Check if user exists in Firebase Auth
    const userRecord = await auth.getUserByEmail(email);
    res.status(200).json({ message: "User exists", userRecord });
  } catch (error) {
    if (error.code === "auth/user-not-found") {
      res.status(404).json({ message: "User does not exist" });
    } else {
      res.status(500).json({ message: "Error checking user", error });
    }
  }
});

module.exports = router;
