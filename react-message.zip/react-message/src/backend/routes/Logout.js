// Example: server/routes/Logout.js
const express = require("express");
const router = express.Router();

// Handle logout
router.post("/logout", (req, res) => {
  res.status(200).json({ message: "Logged out successfully" });
});

module.exports = router;
