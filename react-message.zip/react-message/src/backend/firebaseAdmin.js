// backend/firebaseAdmin.js
const admin = require("firebase-admin");

const serviceAccount = require("./config/real-time-chat-app-d18d8-firebase-adminsdk-33y3f-dc42fdcaa6.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const auth = admin.auth();

module.exports = auth;
