const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const contactsRouter = require("./routes/contacts");
const usersRouter = require("./routes/users");

const app = express();
const port = 5000; // or any port you prefer
app.get("/", (req, res) => {
  res.send("Server is running!");
});
app.use(cors()); // Enable CORS if you're accessing from a different origin
app.use(bodyParser.json()); // Parse JSON bodies

// Use the routes
app.use("/api/users", usersRouter); // Ensure this path matches the endpoint you're testing
app.use("/api/contacts", contactsRouter); // Ensure this path is correct

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
