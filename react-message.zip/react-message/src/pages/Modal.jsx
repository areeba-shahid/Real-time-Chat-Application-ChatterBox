import React, { useState, useEffect } from "react";
import styles from "./MainPage.module.css";
import axios from "axios";
import { addContact } from "../features/addContact";

const Modal = ({
  setShowModal,
  setContacts,
  contacts,
  contactToEdit,
  setContactToEdit,
  onUpdateContact,
}) => {
  const [newContactName, setNewContactName] = useState("");
  const [newContactEmail, setNewContactEmail] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (contactToEdit) {
      setNewContactName(contactToEdit.name);
      setNewContactEmail(contactToEdit.email);
    }
  }, [contactToEdit]);

  const handleAddOrUpdateContact = async () => {
    // Basic validation checks
    if (!newContactEmail) {
      setError("Please enter an email");
      return;
    }
    if (!newContactName) {
      setError("Please enter a name");
      return;
    }
    const updatedContact = {
      id: contactToEdit?.id,
      name: newContactName,
      email: newContactEmail,
    };
    if (contactToEdit) {
      await onUpdateContact(updatedContact);
      // Update existing contact
      const updatedContacts = contacts.map((contact) =>
        contact.email === contactToEdit.email
          ? { ...contact, name: newContactName }
          : contact
      );
      setContacts(updatedContacts);
    } else {
      // Check if the contact already exists
      const isContactExists = contacts.some(
        (contact) => contact.email === newContactEmail
      );
      if (isContactExists) {
        setError("Contact with this email already exists in the list");
        return;
      }

      try {
        const response = await axios.get(
          `/api/users/check-email/${newContactEmail}`
        );
        if (response.data.exists) {
          await addContact({ name: newContactName, email: newContactEmail });
          setContacts((prevContacts) => [
            ...prevContacts,
            { name: newContactName, email: newContactEmail },
          ]);
        } else {
          setError("User does not exist");
          return;
        }
      } catch (error) {
        setError("An error occurred while checking the user");
        return;
      }
    }

    // Reset form and state
    setNewContactName("");
    setNewContactEmail("");
    setError("");
    setContactToEdit(null);
    setShowModal(false);
  };

  function handleCancel() {
    setContactToEdit(null);
    setShowModal(false);
  }

  return (
    <div className={styles.modalBackdrop}>
      <div className={styles.modal}>
        <h2>{contactToEdit ? "Update Contact" : "Add New Contact"}</h2>
        <input
          type="text"
          placeholder="Enter name"
          value={newContactName}
          onChange={(e) => setNewContactName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Enter email"
          value={newContactEmail}
          onChange={(e) => setNewContactEmail(e.target.value)}
          disabled={!!contactToEdit} // Disable email input if editing
          required
        />
        <button onClick={handleAddOrUpdateContact}>
          {contactToEdit ? "Update" : "Add"}
        </button>

        <button onClick={handleCancel}>Cancel</button>
        {error && <p>{error}</p>}
      </div>
    </div>
  );
};

export default Modal;
