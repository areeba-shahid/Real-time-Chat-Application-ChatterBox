import React, { useState, useEffect } from "react";
import { FaPencilAlt, FaTrashAlt, FaSmile } from "react-icons/fa";
import styles from "./MainPage.module.css";
import MainNav from "../components/MainNav";
import RandomProfilePic from "../components/RandomProfilePic";
import EmojiPicker from "emoji-picker-react";
import Modal from "./Modal";
import LogoutButton from "../components/LogoutButton";
import { fetchContacts } from "../features/FetchContacts";
import { updateContact } from "../features/updateContact";
import { deleteContact } from "../features/deleteContact";
import { sendMessage } from "../features/SendingMessages";
import Messages from "../components/Messages"; // Chat window
import { getUserIdByEmail } from "../features/getUserIdByEmai";
function MainPage() {
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [message, setMessage] = useState("");
  const [contacts, setContacts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [search, setSearch] = useState("");
  const [filteredContacts, setFilteredContacts] = useState([]);
  const [contactToEdit, setContactToEdit] = useState(null);
  const [selectedContactToChat, setSelectedContactToChat] = useState(null);

  useEffect(() => {
    if (search) {
      const searchedContacts = contacts.filter((contact) =>
        contact.name.toLowerCase().includes(search.toLowerCase())
      );
      const otherContacts = contacts.filter(
        (contact) => !contact.name.toLowerCase().includes(search.toLowerCase())
      );
      setFilteredContacts([...searchedContacts, ...otherContacts]);
    } else {
      setFilteredContacts(contacts);
    }
  }, [search, contacts]);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("user"));
    const userId = user?.uid;

    if (userId) {
      const loadContacts = async () => {
        try {
          const contacts = await fetchContacts(userId);
          setContacts(contacts);
        } catch (error) {
          console.error("Error fetching contacts:", error.message);
        }
      };
      loadContacts();
    }
  }, []);

  const handleEmojiButtonClick = () => {
    setShowEmojiPicker((prev) => !prev);
  };

  const handleEmojiClick = (emojiObject) => {
    setMessage((prevMessage) => prevMessage + emojiObject.emoji);
  };

  const handleDelete = async (contact) => {
    const user = JSON.parse(localStorage.getItem("user"));
    const userId = user.uid;

    const contactId = contact.id;
    if (userId) {
      try {
        await deleteContact(userId, contactId);
        setContacts((prevContacts) =>
          prevContacts.filter((contact) => contact.id !== contactId)
        );
      } catch (error) {
        console.error("Error deleting contact:", error.message);
      }
    }
  };

  const handleUpdate = (id, name, email) => {
    setContactToEdit({ id, name, email });
    setShowModal(true);
  };

  const handleUpdateContact = async (updatedContact) => {
    const user = JSON.parse(localStorage.getItem("user"));
    const userId = user.uid;
    if (userId) {
      try {
        await updateContact(userId, updatedContact.id, updatedContact);
        setContacts((prevContacts) =>
          prevContacts.map((contact) =>
            contact.id === updatedContact.id ? updatedContact : contact
          )
        );
        setShowModal(false);
      } catch (error) {
        console.error("Error updating contact:", error.message);
      }
    }
  };

  const handleSendMessage = async () => {
    const user = JSON.parse(localStorage.getItem("user"));
    const userId = user.uid;
    const receiverEmail = selectedContactToChat?.email;
    const receiverId = await getUserIdByEmail(receiverEmail);
    const messageText = message;

    if (userId && receiverId && messageText.trim()) {
      try {
        await sendMessage(userId, receiverId, messageText);
        setMessage("");
      } catch (error) {
        console.error("Error sending message:", error.message);
      }
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.sidebar}>
        <MainNav
          onClick={() => setShowModal(true)}
          search={search}
          setSearch={setSearch}
        />
        <ul className={styles.contactList}>
          {filteredContacts.map((contact, index) => (
            <div
              key={index}
              className={styles.contactItem}
              onClick={() => setSelectedContactToChat(contact)}
            >
              <RandomProfilePic className={styles.profilePic} />
              <span>{contact.name}</span>

              <button
                onClick={() =>
                  handleUpdate(contact.id, contact.name, contact.email)
                }
                className={styles.updateButton}
              >
                <FaPencilAlt />
              </button>
              <button
                onClick={() => handleDelete(contact)}
                className={styles.deleteButton}
              >
                <FaTrashAlt />
              </button>
            </div>
          ))}
        </ul>
        <LogoutButton />
      </div>

      <div className={styles.chatArea}>
        <div>
          {selectedContactToChat ? (
            <Messages selectedContact={selectedContactToChat} />
          ) : (
            <div className={styles.noChatSelected}>
              <p>Select a contact to start chatting</p>
            </div>
          )}
        </div>
        <div className={styles.keyboard}>
          <button
            className={`${styles.iconButton} ${styles.iconSpacing}`}
            onClick={handleEmojiButtonClick}
          >
            <FaSmile />
          </button>
          <input
            type="text"
            className={styles.input}
            placeholder="Type a message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          <button className={styles.sendButton} onClick={handleSendMessage}>
            Send
          </button>

          {showEmojiPicker && (
            <div className={styles.emojiPicker}>
              <EmojiPicker onEmojiClick={handleEmojiClick} />
            </div>
          )}
        </div>
      </div>
      {showModal && (
        <Modal
          setShowModal={setShowModal}
          setContacts={setContacts}
          contacts={contacts}
          contactToEdit={contactToEdit}
          setContactToEdit={setContactToEdit}
          onUpdateContact={handleUpdateContact}
        />
      )}
    </div>
  );
}

export default MainPage;
