// Home.js
import React from "react";
import styles from "./Home.module.css";
import { Link } from "react-router-dom";
import Navbar from "../components/Navbar";
function Home() {
  return (
    <div className={styles.container}>
      <Navbar />
      <div className={styles.heroSection}>
        <h1 className={styles.heading}>Welcome to ChatterBox</h1>
        <p className={styles.subheading}>
          Connect, chat, and share in real-time with your friends and
          colleagues.
        </p>
        <Link to="/signup" className={styles.ctaButton}>
          Get Started
        </Link>
      </div>
      <section className={styles.features}>
        <div className={styles.feature}>
          <h2 className={styles.featureTitle}>Real-Time Messaging</h2>
          <p className={styles.featureDescription}>
            Experience seamless and instant messaging with our robust real-time
            chat system.
          </p>
        </div>
        <div className={styles.feature}>
          <h2 className={styles.featureTitle}>User-Friendly Interface</h2>
          <p className={styles.featureDescription}>
            Enjoy a clean and intuitive design that makes chatting and managing
            conversations effortless.
          </p>
        </div>
        <div className={styles.feature}>
          <h2 className={styles.featureTitle}>Secure and Private</h2>
          <p className={styles.featureDescription}>
            Your privacy is our priority. Enjoy secure conversations with
            end-to-end encryption.
          </p>
        </div>
      </section>
    </div>
  );
}

export default Home;
