// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth"; // Import the auth functions

const firebaseConfig = {
  apiKey: "AIzaSyCunD1ow9FCJyIyxBVAbdhPxqTbQY7D0cc",
  authDomain: "real-time-chat-app-d18d8.firebaseapp.com",
  projectId: "real-time-chat-app-d18d8",
  storageBucket: "real-time-chat-app-d18d8.appspot.com",
  messagingSenderId: "989026178413",
  appId: "1:989026178413:web:40a8f24a794189967ef664",
  measurementId: "G-1MD11PWV10",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const analytics = getAnalytics(app);
const auth = getAuth(app);

export {
  app,
  analytics,
  auth,
  db,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
};
