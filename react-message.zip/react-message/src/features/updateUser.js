import { db } from "../firebase"; // Import your Firestore instance
import { doc, setDoc } from "firebase/firestore";

export const addUserToFirestore = async (userRecord) => {
  try {
    // Reference to the Firestore `users` collection
    const userDocRef = doc(db, "users", userRecord.uid);

    // Add or update user information
    await setDoc(userDocRef, {
      email: userRecord.email,
    });

    console.log("User added/updated successfully in Firestore");
  } catch (error) {
    console.error("Error adding/updating user in Firestore: ", error);
  }
};
