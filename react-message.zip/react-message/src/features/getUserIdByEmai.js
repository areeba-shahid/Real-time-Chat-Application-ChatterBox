import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "../firebase";

export const getUserIdByEmail = async (email) => {
  try {
    const usersRef = collection(db, "users");
    const q = query(usersRef, where("email", "==", email));
    const querySnapshot = await getDocs(q);

    if (querySnapshot.empty) {
      throw new Error(`User with email ${email} not found`);
    }

    const userDoc = querySnapshot.docs[0]; // Assume unique email
    return userDoc.id; // Return the user ID
  } catch (error) {
    console.error(`Error in getUserIdByEmail: ${error.message}`);
    throw error; // Re-throw the error for handling in fetchMessages
  }
};
