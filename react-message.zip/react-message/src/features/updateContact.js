import {
  collection,
  query,
  where,
  getDocs,
  doc,
  updateDoc,
} from "firebase/firestore";
import { db } from "../firebase";

const updateContact = async (userId, contactId, updatedData) => {
  if (!userId || !contactId || !updatedData) {
    console.error("Missing parameters for updating contact.");
    return;
  }

  try {
    const contactsRef = collection(db, "users", userId, "contacts");
    const q = query(contactsRef, where("id", "==", contactId));
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      const contactDoc = querySnapshot.docs[0];
      const contactDocRef = doc(db, "users", userId, "contacts", contactDoc.id);

      await updateDoc(contactDocRef, updatedData);
      console.log("Contact updated successfully");
    } else {
      console.error("Contact not found in Firestore");
    }
  } catch (error) {
    console.error("Error updating contact:", error);
  }
};

export { updateContact };
