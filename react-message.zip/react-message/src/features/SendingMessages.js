// src/features/sendMessage.js
import { db } from "../firebase";
import {
  collection,
  addDoc,
  doc,
  setDoc,
  serverTimestamp,
  query,
  where,
  getDocs,
  updateDoc,
} from "firebase/firestore";

export const sendMessage = async (senderId, receiverId, messageText) => {
  try {
    // Generate a unique chat ID by sorting and concatenating user IDs
    const chatId =
      senderId > receiverId
        ? `${senderId}_${receiverId}`
        : `${receiverId}_${senderId}`;

    const chatRef = doc(db, "chats", chatId);
    const messagesRef = collection(chatRef, "messages");

    // Check if chat exists
    const chatDoc = await getDocs(
      query(collection(db, "chats"), where("__name__", "==", chatId))
    );

    if (chatDoc.empty) {
      // Create chat document if it doesn't exist
      await setDoc(chatRef, {
        participants: [senderId, receiverId],
        lastMessage: messageText,
        lastUpdated: serverTimestamp(),
      });
    } else {
      // Update lastMessage and lastUpdated
      await updateDoc(chatRef, {
        lastMessage: messageText,
        lastUpdated: serverTimestamp(),
      });
    }

    // Add message to messages subcollection
    await addDoc(messagesRef, {
      senderId,
      receiverId,
      content: messageText,
      timestamp: serverTimestamp(),
    });

    console.log("Message sent successfully");
  } catch (error) {
    console.error("Error sending message: ", error);
  }
};
