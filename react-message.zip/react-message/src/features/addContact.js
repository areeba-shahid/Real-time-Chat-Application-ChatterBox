import { db } from "../firebase";
import { collection, addDoc, query, where, getDocs } from "firebase/firestore";
import { getUserIdByEmail } from "./getUserIdByEmai"; // Import the function to get user ID by email

const addContact = async (contact) => {
  const user = JSON.parse(localStorage.getItem("user"));
  const userId = user.uid;

  try {
    // Reference to the user's contacts collection
    const contactsRef = collection(db, "users", userId, "contacts");

    // Check if the contact already exists
    const q = query(contactsRef, where("email", "==", contact.email));
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      console.log("Contact already exists");
      return;
    }

    const contactUserId = await getUserIdByEmail(contact.email);

    await addDoc(contactsRef, {
      id: contactUserId, // Store the contact's user ID
      email: contact.email,
      name: contact.name,
    });

    console.log("Contact added successfully");
  } catch (error) {
    console.error("Error adding contact: ", error);
  }
};

export { addContact };
