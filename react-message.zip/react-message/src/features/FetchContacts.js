import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";

const fetchContacts = async (userId) => {
  const contactsRef = collection(db, `users/${userId}/contacts`);
  const snapshot = await getDocs(contactsRef);
  const contacts = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  return contacts;
};
export { fetchContacts };
