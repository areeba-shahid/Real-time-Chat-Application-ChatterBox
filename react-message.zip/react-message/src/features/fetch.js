import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { db } from "../firebase";
import { getUserIdByEmail } from "./getUserIdByEmai";

export const fetchMessages = async (userEmail, contactEmail, callback) => {
  // Return a promise that resolves with the unsubscribe function
  return getUserIdByEmail(userEmail)
    .then((userId) =>
      getUserIdByEmail(contactEmail).then((contactId) => {
        // console.log(userId);
        // console.log(contactId);
        const chatId =
          userId > contactId
            ? `${userId}_${contactId}`
            : `${contactId}_${userId}`;

        const messagesRef = collection(db, "chats", chatId, "messages");
        const q = query(messagesRef, orderBy("timestamp", "asc"));

        // Set up the real-time listener
        const unsubscribe = onSnapshot(q, (querySnapshot) => {
          const messages = querySnapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          }));
          callback(messages);
        });

        return unsubscribe; // Return unsubscribe function
      })
    )
    .catch((error) => {
      console.error("Error fetching messages:", error);
      // Return a no-op function in case of an error
      return () => {};
    });
};
