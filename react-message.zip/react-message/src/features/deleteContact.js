import {
  collection,
  query,
  where,
  getDocs,
  doc,
  deleteDoc,
} from "firebase/firestore";
import { db } from "../firebase";

const deleteContact = async (userId, contactId) => {
  if (!userId || !contactId) {
    console.error("Missing parameters for deleting contact.");
    return;
  }

  try {
    const contactsRef = collection(db, "users", userId, "contacts");
    const q = query(contactsRef, where("id", "==", contactId));
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      const contactDoc = querySnapshot.docs[0];
      const contactDocRef = doc(db, "users", userId, "contacts", contactDoc.id);

      await deleteDoc(contactDocRef);
      console.log("Contact deleted successfully");
    } else {
      console.error("Contact not found in Firestore");
    }
  } catch (error) {
    console.error("Error deleting contact:", error);
  }
};

export { deleteContact };
