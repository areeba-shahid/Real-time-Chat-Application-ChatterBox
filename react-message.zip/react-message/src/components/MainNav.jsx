import React from "react";
import styles from "./MainNav.module.css";
import { FaSearch, FaUser, FaPlus } from "react-icons/fa";

function MainNav({ onClick, search, setSearch }) {
  return (
    <div className={styles.navbar}>
      <div className={styles.leftSection}>
        <h2 className={styles.heading}>Chats</h2>
        <div className={styles.iconContainer} onClick={onClick}>
          <FaUser className={styles.userIcon} />
          <FaPlus className={styles.plusIcon} />
        </div>
      </div>
      <input
        type="text"
        className={styles.searchInput}
        placeholder="Search"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <FaSearch className={styles.searchIcon} />
    </div>
  );
}

export default MainNav;
