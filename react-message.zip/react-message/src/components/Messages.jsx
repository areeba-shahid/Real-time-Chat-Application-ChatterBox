import React, { useState, useEffect } from "react";
import { fetchMessages } from "../features/fetch";
import styles from "./messages.module.css";

const Messages = ({ selectedContact }) => {
  const user = JSON.parse(localStorage.getItem("user"));
  const userEmail = user.email;
  const userId = user.uid;

  const [messages, setMessages] = useState([]);

  useEffect(() => {
    if (userEmail && selectedContact.email) {
      const fetchMessagesCallback = (newMessages) => {
        newMessages.forEach((msg) => {
          if (!msg.timestamp) {
            console.warn("Message without timestamp:", msg);
          }
        });
        setMessages(newMessages);
      };

      // Use async/await to handle the promise
      const fetchMessagesAsync = async () => {
        const unsubscribe = await fetchMessages(
          userEmail,
          selectedContact.email,
          fetchMessagesCallback
        );

        // Clean up function to call unsubscribe
        return () => {
          if (typeof unsubscribe === "function") {
            unsubscribe();
          } else {
            console.error(
              "Expected unsubscribe to be a function, but got:",
              unsubscribe
            );
          }
        };
      };

      // Set up the listener and clean up
      const cleanup = fetchMessagesAsync();

      // Clean up on component unmount
      return () => {
        cleanup.then((cleanupFn) => {
          if (typeof cleanupFn === "function") {
            cleanupFn();
          }
        });
      };
    }
  }, [selectedContact, userEmail]);

  const allMessages = messages.sort((a, b) => {
    // Handle null or undefined timestamps
    const aTimestamp = a.timestamp?.seconds || 0;
    const bTimestamp = b.timestamp?.seconds || 0;

    return aTimestamp - bTimestamp;
  });

  return (
    <div className={styles.chatWindow}>
      <div className={styles.chatHeader}></div>
      <div className={styles.messageContainer}>
        {allMessages.map((msg) => (
          <div
            key={msg.id}
            className={
              msg.senderId === userId
                ? styles.sentMessage
                : styles.receivedMessage
            }
          >
            <p>{msg.content}</p>
            <small>
              <span>
                {msg.timestamp
                  ? new Date(msg.timestamp.toDate()).toLocaleTimeString()
                  : "No Timestamp"}
              </span>
            </small>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Messages;
