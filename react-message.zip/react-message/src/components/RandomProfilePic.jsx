import React, { useEffect, useState } from "react";

const RandomProfilePic = ({ userId }) => {
  const [profilePic, setProfilePic] = useState("");

  useEffect(() => {
    const getProfilePic = async () => {
      const url = await fetchRandomProfilePic();
      setProfilePic(url);
    };

    getProfilePic();
  }, [userId]); // Re-run if `userId` changes

  return (
    <div>
      {profilePic ? (
        <img
          src={profilePic}
          alt="Random Profile"
          style={{
            width: "40px",
            height: "40px",
            borderRadius: "50%",
            marginRight: "18px",
          }}
        />
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
};

const fetchRandomProfilePic = async () => {
  try {
    const response = await fetch("https://randomuser.me/api/");
    const data = await response.json();
    const profilePicUrl = data.results[0].picture.large;
    return profilePicUrl;
  } catch (error) {
    console.error("Error fetching random profile picture:", error);
    return null;
  }
};

export default RandomProfilePic;
