import React from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.jpeg";
import styles from "./Navbar.module.css";
const Navbar = () => {
  return (
    <nav className={styles.navbar}>
      <img src={logo} alt="Logo" className={styles.logo} />
      <ul className={styles.navLinks}>
        <li>
          <Link to="/login" className={styles.navLink}>
            Login
          </Link>
        </li>
        <li>
          <Link to="/signup" className={styles.navLink}>
            Sign Up
          </Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
