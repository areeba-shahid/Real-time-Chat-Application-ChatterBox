import { configureStore } from "@reduxjs/toolkit";

import contactsReducer from "../src/features/FetchContacts";
import messagesReducer from "../src/features/FetchMessages";

export const store = configureStore({
  reducer: {
    contacts: contactsReducer,
    messages: messagesReducer,
  },
});
